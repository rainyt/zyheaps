# turbojpeg

[turbojpeg](http://libjpeg-turbo.virtualgl.org/) decompression on  i386 x86_64 armv7 armv7s and arm64 for iOS.

####Thanks
****
- [43z3com](https://github.com/43z3com) 
- [开源中国社区](http://www.oschina.net/) 

####About
- [西贝贾](https://twitter.com/jyhprivate)