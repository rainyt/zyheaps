hlsdl
=====

HLSDL is a SDL2 backend for HashLink 
Read https://www.libsdl.org/ for more information on SDL

In order to compile on Windows, download the Development Libraries from SDL2 and unzip them into the hashlink/include/sdl directory, so you have the directories hashlink/include/sdl/include and hashlink/include/sdl/lib available.


