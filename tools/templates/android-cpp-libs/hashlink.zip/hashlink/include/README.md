The `/include` directory contains third party code that is distributed with HashLink in order to ease compilation (on Windows in particular).
See respective license and copyright for each of these libraries.
