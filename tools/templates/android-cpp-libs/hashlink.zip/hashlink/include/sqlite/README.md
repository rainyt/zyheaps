# SQLite

C source code as an amalgamation, version 3.15.1

 [Download page](http://www.sqlite.org/download.html)
